<template>
    <div>
       <div class="my-title">
          <div class="nameimg">
              <img src="../../style/img/tou.jpg" alt="">
           <h5 class=" namecls">Naaaa</h5>
           </div> 
           <div class="content">
           <div class="title-content">
               <h5>总资产（元）</h5>
               <p>￥0.00</p>
           </div>
            <div class="title-content fontaligin">
               <h5>等级</h5>
               <p>环保达人</p>
           </div>
           </div>

       </div>
       <div class="money-button">
           <h4>取现</h4>
           <h4 class="jifen">积分:<span>22</span></h4>
       </div>
       <div>
           <ul class="my">
               <li class="my-content">
                   <div class="my-list">
                       <img src="../../style/my-icon/information.png" alt="">
                       <h6>个人信息</h6>
                       <img src="../../style/my-icon/right.png" alt="">

                   </div>
               </li>
               <li class="my-content">
                   <div class="my-list">
                       <img src="../../style/my-icon/address.png" alt="">
                       <h6>收货地址管理</h6>
                       <img src="../../style/my-icon/right.png" alt="">

                   </div>
               </li>
                <li class="my-content">
                   <div class="my-list">
                       <img src="../../style/my-icon/juan.png" alt="">
                       <h6>随手捐赠</h6>
                       <img src="../../style/my-icon/right.png" alt="">

                   </div>
               </li>
                <li class="my-content">
                   <div class="my-list">
                       <img src="../../style/my-icon/zaunshimall.png" alt="">
                       <h6>积分商城</h6>
                       <img src="../../style/my-icon/right.png" alt="">

                   </div>
               </li>
                <li class="my-content">
                   <div class="my-list">
                       <img src="../../style/my-icon/fanhui.png" alt="">
                       <h6>反馈问题</h6>
                       <img src="../../style/my-icon/right.png" alt="">

                   </div>
               </li>
                <li class="my-content">
                   <div class="my-list">
                       <img src="../../style/my-icon/call.png" alt="">
                       <h6>联系客服</h6>
                       <img src="../../style/my-icon/right.png" alt="">

                   </div>
               </li>
           </ul>
       </div>
    </div>
</template>
<script>
import '../../lib/mui/css/my.scss'
export default {
    
}

</script>
<style lang="scss" scoped>

</style>