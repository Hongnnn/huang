<template>
  <div >
    <!-- <header> -->
     
      <!-- <routr-view>
        table -->
        <router-view></router-view>
    
  
  </div>
</template>

<script>
</script>


<style lang="scss" scoped>

</style>
 